import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SalesPersonHomeComponent } from './salesperson-home/salesperson-home.component';
import { SalesPersonRoutingModule } from './salesperson-routing.module';

@NgModule({
  declarations: [
    SalesPersonHomeComponent
   
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SalesPersonRoutingModule
  ],
  exports: [
    SalesPersonRoutingModule,
    SalesPersonHomeComponent
  ]
})
export class SalesPersonModule { }
