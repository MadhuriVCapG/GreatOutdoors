import { Component, OnInit } from '@angular/core';
import { SalesPerson } from 'src/app/Models/SalesPerson';
import { SalesPersonsService } from 'src/app/Services/salespersons.service';

@Component({
  selector: 'app-salesperson-home',
  templateUrl: './salesperson-home.component.html',
  styleUrls: ['./salesperson-home.component.scss']
})
export class SalesPersonHomeComponent implements OnInit {

  salesPerson: SalesPerson[];
  currentUser: SalesPerson;
  constructor(private salesPersonsService: SalesPersonsService) {
   
    
  }

  ngOnInit() {
    this.salesPersonsService.GetSalesPersonByEmailAndPassword().subscribe((response) => {
      this.salesPerson = response;
      console.log(response);
      }, (error) => {
      console.log(error);
    })
  }
}
