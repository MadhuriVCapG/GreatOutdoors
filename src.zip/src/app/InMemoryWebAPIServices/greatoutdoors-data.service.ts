import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { SalesPerson } from '../Models/SalesPerson';
import { Admin } from '../Models/Admin';
import { Product } from '../Models/Product';


@Injectable({
  providedIn: 'root'
})
export class GreatOutdoorsDataService implements InMemoryDbService {
  constructor() { }

  createDb() {
    let admins = [
      new Admin(1, '101', 'Admin', 'admin@capgemini.com', 'manager')
    ];

    let salespersons = [
      new SalesPerson(1, "401476EE-0A3B-482E-BD5B-B94A32355959", "Scott", "9876543210", "scott@capgemini.com", "Scott123", 20000, 50000,5000, "10/10/2013",
        "5-23-4,Sector 12,Mumbai,Maharashtra-400503", "23/06/1985", "10/04/2019"),

      new SalesPerson(2, "C628855C-FE7A-4D94-A1BB-167157D3F4EA", "Smith", "9988776655", "smith@capgemini.com", "Smith123",
        20000, 50000, 5000,"03/03/2015", "2-20-7,Gandhi Road,Mumbai,Maharashtra-400701","09/06/1992", "05/07/2019"),
    ];

    let products = [
      new Product(1, "D3C8F8E6-6545-4DC3-8524-4E5FD9027481", "BCKPCK", "Back Pack", "Camping", "Insert image here", 10, "Small", "Black", "Material - Polyester, Strap - Adjustable",
        1000, 1200, 10),
      new Product(2, "A4932913-A0C1-49E9-873F-93BF318A08FC", "GSTCK", "Golf Stick", "Golf", "Insert image here", 10, "Small", "White", "Hand Orientation - Right",
      500,700, 5),

    ];

   
    return { admins, salespersons, products};
  }
}


