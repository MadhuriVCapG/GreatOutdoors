export class SalesPerson {
  id: number;
  salesPersonID: string;
  salesPersonName: string;
  salesPersonMobile: string;
  email: string;
  password: string;
  salary: number;
  bonus: number;
  target: number;
  joiningDate: string;
  address: string;
  birthDate: string;
  lastModifiedDateTime: string;

  constructor(ID: number, SalesPersonID: string, SalesPersonName: string, SalesPersonMobile: string, Email: string,
    Password: string, Salary : number,Bonus : number, Target : number,JoiningDate : string,Address : string, BirthDate : string,
    LastModifiedDateTime: string)
  {
    this.id = ID;
    this.salesPersonID = SalesPersonID;
    this.salesPersonName = SalesPersonName;
    this.salesPersonMobile = SalesPersonMobile;
    this.email = Email;
    this.password = Password;
    this.salary = Salary;
    this.bonus = Bonus;
    this.target = Target;
    this.joiningDate = JoiningDate;
    this.address = Address;
    this.birthDate = BirthDate;
    this.lastModifiedDateTime = LastModifiedDateTime;
  }
}


